
  # Aplicar instruções do arquivo

  This is a code bundle for Aplicar instruções do arquivo. The original project is available at https://www.figma.com/design/mYC5adXWpuxr5grokO7LxJ/Aplicar-instru%C3%A7%C3%B5es-do-arquivo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  