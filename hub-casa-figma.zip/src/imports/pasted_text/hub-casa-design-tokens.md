## Hub Casa — UI Design Prompt

You are designing "Hub Casa", a collaborative home management web app.
The visual direction is clean minimalism: generous whitespace, neutral
palette, precise typography, and calm interactions. No decorative
elements — every pixel serves a function.

---

## DESIGN PHILOSOPHY

Inspired by: Linear, Basecamp, Plain
Tone: Quiet confidence. Nothing fights for attention.
Rule: If removing an element doesn't break understanding, remove it.

Anti-patterns to avoid:
- Colored backgrounds on cards
- Gradient fills
- Drop shadows (except subtle focus rings)
- Icon overload — use icons only where they replace a word
- Dense information without breathing room

---

## DESIGN TOKENS

### Colors
--white: #FFFFFF
--gray-50: #F8F8F7
--gray-100: #F0EFED
--gray-200: #E4E3E0
--gray-300: #C8C7C3
--gray-400: #9B9A96
--gray-500: #6B6A67
--gray-700: #3D3C3A
--gray-900: #1A1917
--black: #0D0C0B

--accent: #1A1917      (primary action — near-black)
--accent-hover: #3D3C3A
--blue: #2563EB        (financial module)
--purple: #7C3AED      (tasks module)
--amber: #D97706       (calendar module)
--green: #059669       (positive values, paid status)
--red: #DC2626         (alerts, overbudget, destructive)

### Typography
Font stack: "Geist" (primary) + "Geist Mono" (numbers/data)
If Geist unavailable: "Inter" + "IBM Plex Mono"

Scale:
--text-xs:   11px / 1.4  weight 400
--text-sm:   13px / 1.5  weight 400
--text-base: 14px / 1.6  weight 400
--text-md:   16px / 1.5  weight 500
--text-lg:   20px / 1.3  weight 500
--text-xl:   28px / 1.2  weight 600
--text-2xl:  38px / 1.1  weight 600

Mono font used exclusively for: currency values, dates, 
counts, percentages, IDs.

### Spacing (8px grid)
--space-1: 4px   --space-2: 8px   --space-3: 12px
--space-4: 16px  --space-5: 24px  --space-6: 32px
--space-7: 48px  --space-8: 64px

### Borders & Radius
--border: 0.5px solid #E4E3E0
--radius-sm: 6px   --radius-md: 8px
--radius-lg: 12px  --radius-xl: 16px

---

## RESPONSIVE LAYOUT SYSTEM

### Desktop (≥1024px)
- Left sidebar: 220px fixed
- Top bar: 56px
- Content: fluid, max-width 1200px, centered
- Grid: 12 columns, 24px gap

### Tablet (768–1023px)
- Sidebar collapses to icon-only rail (56px)
- Tap rail icon → overlay drawer slides in
- Content: single column or 2-col grid

### Mobile (< 768px)
- No sidebar — bottom navigation bar (5 items, 64px)
- Top bar: 52px, shows only title + avatar
- Full-width cards, vertical stacking
- Floating action button (FAB) bottom-right for primary action

---

## NAVIGATION STRUCTURE

Items (with module color dot indicator on active):
  Home (Dashboard)
  Financeiro      · blue dot when active
  Tarefas         · purple dot when active
  Agenda          · amber dot when active
  Compras
  Dispensa

Desktop sidebar anatomy:
- Top: 32px logo mark + "Hub Casa" in --text-md
- Nav items: 36px height, 12px horizontal padding,
  icon (16px) + label, 8px gap
- Active: gray-100 background, colored 2px left border
- Bottom: avatar (28px) + user name + house name in --text-xs

Mobile bottom nav:
- 5 icon-only tabs (max), active = colored icon + label appears
- Safe area padding at bottom

---

## SCREEN 1 — DASHBOARD

### Desktop layout
Top greeting row:
  Left: "Bom dia, Gabriel" in --text-xl + --gray-900
        Subtitle: current date in --text-sm + --gray-400 + mono font
  Right: notification bell icon (gray-400), settings icon

4-column stat row (equal cards, 1px border, white bg):
  Card 1 — "Ciclo ativo"
    Cycle name "Dia 25" in --text-xs gray-400 uppercase
    Value "R$ 1.250" in --text-xl mono blue
    Progress bar: 4px height, gray-100 track, blue fill
    Caption: "R$ 812 pagos · R$ 438 pendentes" in --text-xs gray-400 mono

  Card 2 — "A pagar"
    Value "R$ 469,53" in --text-xl mono
    Caption "2 contas · vence hoje" in --text-xs red

  Card 3 — "Tarefas"
    "8 / 12" in --text-xl mono purple
    Caption "concluídas esta semana"
    Thin ring chart (40px): purple fill, gray track

  Card 4 — "Dispensa"
    "3 itens" in --text-xl mono amber
    Caption "abaixo do mínimo"

Main 2-column grid (60% / 40% split):

LEFT — "Ciclos de Pagamento" card:
  3 rows, one per cycle (Dia 10 / Dia 15 / Dia 25)
  Each row (48px height, border-bottom):
    Cycle label "Dia 10" in --text-sm gray-500 mono
    Progress bar (flex-1, 6px height): blue fill, 
      shows % of budget used, goes red if >100%
    Paid amount "R$ 89,00" green mono --text-sm
    Pending amount "R$ 450,00" gray mono --text-sm

  Below: "Sem data" row for flexible expenses
    Same layout, gray pill instead of cycle label

LEFT — "Últimos lançamentos" card (below cycles):
  5 rows, minimal design:
    Left: 8px colored dot (by type) + description text
    Right: amount in mono (expense gray-700, income green)
    Below description: category tag (gray-100 pill, gray-500 text)
    Date in --text-xs gray-400 mono, right-aligned
  "Ver todos" link bottom right, --text-sm gray-400

RIGHT — "Tarefas de hoje" card:
  Day label "Sexta, 13" in --text-sm gray-400
  Task list (4–5 items):
    Checkbox (unchecked: gray-200 border, 16px circle)
    Task title --text-sm gray-900
    2px left border in purple
    Assignee avatar (20px) right-aligned
    Completed: strikethrough, gray-400, 50% opacity

RIGHT — "Próximos compromissos" card:
  3 items, minimal list:
    Time "14:30" in --text-xs mono amber
    Title in --text-sm
    1px separator between items

### Mobile layout (same screen)
- Greeting full width, smaller
- Stat cards: 2×2 grid (2 columns, 2 rows)
- Cycle progress: single column card
- Tasks and agenda: stacked full-width cards
- Bottom nav replaces sidebar

---

## SCREEN 2 — FINANCEIRO

Page header:
  "Financeiro" in --text-xl
  Tab row below (underline style, no pill background):
  "Visão Geral" | "Lançamentos" | "Ciclos" | "Histórico"
  Active tab: black underline 2px, black text
  Inactive: gray-400, no underline

### Tab: Visão Geral

3 cycle summary cards (horizontal row, equal width):
  Each card — minimal, 1px border, white bg:
    Header row: "Ciclo · Dia 15" --text-sm gray-500
                Status dot "Ativo" — small green dot + text
    Large value: "R$ 1.906,18" --text-2xl mono blue
    Divider 1px
    Two rows:
      "Pago"     "R$ 1.436,65"  green mono --text-base
      "Pendente" "R$ 469,53"    amber mono --text-base
    Progress bar: 8px, rounded, blue fill, gray-100 track
    Overbudget state: bar turns red, card border turns red 0.5px

  "Sem data" card (4th): same layout, gray accent, 
    title "Sem data fixo"

### Tab: Lançamentos (full table view)

Filter row:
  Chips (pill style, 1px border): 
  "Todos" | "Pago" | "Pendente" | "Recorrente" | "Parcelado"
  Active chip: gray-900 bg, white text
  Inactive chip: white bg, gray-300 border, gray-600 text

  Right side: "Novo lançamento" button (black fill, white text)

Table (clean, no cell borders — row separator only):
  Columns: Descrição · Valor · Vencimento · Ciclo · Status · —

  Row anatomy (48px height):
    Descrição: primary text --text-sm gray-900
               secondary: category tag pill below (gray-100 bg)
               if parcelado: "2 de 3 parcelas" in --text-xs gray-400 mono
    Valor: right-aligned, mono --text-sm
           expense: gray-900  |  income: green
    Vencimento: mono --text-sm gray-500
    Ciclo: pill "Dia 15" blue tinted (blue-50 bg, blue text)
           or "Sem data" gray pill
    Status: pill
           "Pago"           → green-50 bg, green-700 text
           "Aberto"         → amber-50 bg, amber-700 text
           "Impossibilitado"→ gray-100 bg, gray-500 text
    Actions column: "..." menu icon (appears on row hover only)

  Table footer: total row, bold, separator above

### Side drawer — "Novo Lançamento"
  Slides in from right, 400px wide (mobile: full screen bottom sheet)
  Overlay: gray-900 at 20% opacity behind drawer

  Drawer anatomy:
    Header: "Novo lançamento" --text-md + close X icon
    Divider
    Form fields (vertical stack, 16px gap):
      Título — text input, placeholder "Ex: Conta de luz"
      Valor  — number input, "R$" prefix fixed, mono font
      Tipo   — segmented control:
               Gasto | Ganho | Dívida | Empréstimo | Afiado
               Selected: black bg white text, unselected: white/gray-200
      Categoria — select dropdown with 8px colored icon dot per option
      Vencimento — date input (native or custom)
      Ciclo    — select: Dia 10 / Dia 15 / Dia 25 / Sem data
      Recorrente — toggle (off by default)
                   if OFF → show "Parcelas" number input
                   if ON  → show "Recorrência" select 
                            (Mensal / Anual / Diária / Fixa)
      Responsáveis — multi-select: shows avatar chips when selected
    Divider
    Footer row:
      "Cancelar" — ghost button, gray-500
      "Salvar"   — solid button, black bg white text, full remaining width

---

## SCREEN 3 — TAREFAS (Kanban semanal)

Page header: "Tarefas" + week range "10–16 março" in gray-400
Right: "< Semana anterior" · "Próxima semana >" navigation

Board layout: 7 columns (Mon–Sun), horizontal scroll on mobile
Each column: 120px min-width, 1px right border (gray-100), 
             no background color

Column header:
  Day abbreviation "SEG" --text-xs gray-400 uppercase letter-spacing
  Date number "10" --text-lg gray-700 (today = black + black dot above)
  Task count badge: "3" in gray-200 pill, --text-xs mono

Task card (draggable):
  White bg, 1px border gray-200, radius-md, padding 10px 12px
  Left border 3px in assigned color (or purple default)
  Title: --text-sm gray-900
  If has description: chevron icon (expand on click)
  Bottom row:
    Assignee avatars (stack, 20px each) left
    Completed checkbox right (circle, 16px)
  Completed state: gray-100 bg, strikethrough title, 50% opacity

  Drag state: slight scale(1.02), border-color gray-400, 
              cursor grabbing

"+" button below last card in each column:
  --text-sm gray-400, no border, full column width
  Hover: gray-50 bg

Empty column: dashed 1px border gray-200, 
  "Nenhuma tarefa" --text-xs gray-300 centered

### New task inline creation
Click "+" → inline input appears at bottom of column:
  White card, blue 1px border
  Title input focused, placeholder "Nome da tarefa..."
  ESC to cancel, Enter to save (add more details later in drawer)

### Task detail drawer (right side, 360px)
  Task title (editable h2)
  Dia da semana: current column day
  Descrição: textarea, placeholder "Adicionar descrição..."
  Responsáveis: avatar multi-select
  Cor: 8 color swatches (small circles, 20px each)
  Status toggle: "Concluída" checkbox
  Danger zone: "Excluir tarefa" link, gray-400, small

---

## COMPONENT LIBRARY PAGE

Document every component in a dedicated Figma page named "Components".

### Buttons
- Primary: black bg, white text, radius-md, 36px height
- Secondary: white bg, 1px border gray-300, gray-900 text
- Ghost: no border, gray-500 text, hover gray-100 bg
- Danger: red-50 bg, red-700 text, 1px red-200 border
- Icon only: 32px square, radius-md
- Loading: spinner replaces text/icon, same dimensions

### Form elements
- Input: 36px height, 1px border gray-200, radius-md
         focus: 1.5px border gray-900, no shadow
         error: red border, red helper text below
- Select: same dimensions as input, chevron icon right
- Toggle: 32×18px track, 14px thumb, 
          off: gray-200 track, on: gray-900 track
- Checkbox: 16px circle (tasks) or 16px square (forms)
- Date picker: input with calendar popover
- Segmented control: outlined group, active segment filled black

### Data display
- Stat card: white bg, 1px border, radius-lg, 20px padding
             label --text-xs gray-400, value --text-xl mono
- Cycle card: same as stat card + progress bar component
- Progress bar: 4px/6px/8px variants, animated fill, 
                blue default, red overbudget
- Status pill: 3 variants (pago/aberto/impossibilitado)
- Cycle pill: blue tinted, "Dia 10/15/25" or "Sem data" gray
- Category tag: gray-100 bg, gray-600 text, 20px height pill
- Avatar: 20/28/32/40px sizes, circle, initials fallback
- Avatar stack: max 3 visible + "+N" overflow

### Feedback
- Empty state: centered, --text-sm gray-400, optional CTA button
- Skeleton loader: gray-100 animated pulse, matches component shape
- Toast notification: bottom-center, white card 1px border, 
                      colored left border by type
- Confirmation dialog: centered modal, 480px wide, 
                       destructive action in red button

---

## INTERACTION NOTES

Transitions: 150ms ease for all hover/focus states
Drawer: 200ms ease-out slide from right
Modal: 150ms fade-in + subtle scale from 0.97 to 1
Drag (tasks): instant grab, 200ms settle on drop
Progress bars: animate fill on mount, 400ms ease-out
Skeleton: pulse 1.5s infinite

Responsive breakpoints:
  mobile:  < 768px
  tablet:  768px – 1023px
  desktop: ≥ 1024px

Hover states required on: all buttons, table rows, 
nav items, task cards, action icons

---

## DELIVERABLES EXPECTED FROM FIGMA MAKE

1. Design tokens page (colors, type, spacing)
2. Components page (all components documented)
3. Dashboard — desktop + mobile
4. Financeiro — desktop (Visão Geral + Lançamentos tabs) + mobile
5. Tarefas — desktop kanban + mobile (vertical list)
6. Prototype connections between screens (basic flow)