import { useState } from "react";
import { Plus, AlertTriangle } from "lucide-react";

interface PantryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  minimum: number;
  category: string;
  lastUpdated: string;
}

const initialItems: PantryItem[] = [
  { id: "1", name: "Arroz", quantity: 0.5, unit: "kg", minimum: 2, category: "Grãos", lastUpdated: "12/03" },
  { id: "2", name: "Feijão", quantity: 3, unit: "kg", minimum: 1, category: "Grãos", lastUpdated: "10/03" },
  { id: "3", name: "Açúcar", quantity: 0.2, unit: "kg", minimum: 1, category: "Grãos", lastUpdated: "08/03" },
  { id: "4", name: "Azeite", quantity: 2, unit: "L", minimum: 1, category: "Condimentos", lastUpdated: "05/03" },
  { id: "5", name: "Sal", quantity: 1, unit: "kg", minimum: 0.5, category: "Condimentos", lastUpdated: "01/03" },
  { id: "6", name: "Macarrão", quantity: 4, unit: "pct", minimum: 2, category: "Massas", lastUpdated: "10/03" },
  { id: "7", name: "Leite (caixinha)", quantity: 1, unit: "L", minimum: 4, category: "Laticínios", lastUpdated: "13/03" },
  { id: "8", name: "Café", quantity: 0.1, unit: "kg", minimum: 0.5, category: "Bebidas", lastUpdated: "14/03" },
  { id: "9", name: "Óleo", quantity: 0.5, unit: "L", minimum: 1, category: "Condimentos", lastUpdated: "07/03" },
  { id: "10", name: "Farinha de trigo", quantity: 5, unit: "kg", minimum: 2, category: "Grãos", lastUpdated: "02/03" },
  { id: "11", name: "Detergente", quantity: 3, unit: "un", minimum: 2, category: "Limpeza", lastUpdated: "06/03" },
  { id: "12", name: "Esponja de louça", quantity: 1, unit: "un", minimum: 3, category: "Limpeza", lastUpdated: "11/03" },
];

const catColors: Record<string, string> = {
  Grãos: "#D97706",
  Laticínios: "#2563EB",
  Massas: "#7C3AED",
  Condimentos: "#059669",
  Bebidas: "#DC2626",
  Limpeza: "#9B9A96",
};

const categories = ["Todos", "Grãos", "Laticínios", "Massas", "Condimentos", "Bebidas", "Limpeza"];

export function Dispensa() {
  const [items, setItems] = useState<PantryItem[]>(initialItems);
  const [filter, setFilter] = useState("Todos");

  const filtered = items.filter((i) => filter === "Todos" || i.category === filter);
  const lowItems = items.filter((i) => i.quantity < i.minimum);

  function adjustQuantity(id: string, delta: number) {
    setItems((prev) =>
      prev.map((i) =>
        i.id === id
          ? { ...i, quantity: Math.max(0, parseFloat((i.quantity + delta * 0.5).toFixed(1))) }
          : i
      )
    );
  }

  function getStockLevel(item: PantryItem): "low" | "ok" | "full" {
    const ratio = item.quantity / item.minimum;
    if (ratio < 1) return "low";
    if (ratio < 2) return "ok";
    return "full";
  }

  const stockColors = {
    low: "#DC2626",
    ok: "#D97706",
    full: "#059669",
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[28px] font-semibold text-[#1A1917]">Dispensa</h1>
          <p className="text-sm text-[#9B9A96] mt-0.5">
            <span className="font-mono">{items.length}</span> itens cadastrados
          </p>
        </div>
        <button className="flex items-center gap-1.5 h-9 px-4 bg-[#1A1917] text-white rounded-[8px] text-sm hover:bg-[#3D3C3A] transition-colors">
          <Plus size={14} />
          Novo item
        </button>
      </div>

      {/* Low stock alert */}
      {lowItems.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-[12px] p-4 mb-5 flex items-start gap-3">
          <AlertTriangle size={16} className="text-[#DC2626] flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-[#DC2626]">
              {lowItems.length} {lowItems.length === 1 ? "item abaixo" : "itens abaixo"} do estoque mínimo
            </p>
            <p className="text-xs text-[#DC2626]/70 mt-0.5">
              {lowItems.map((i) => i.name).join(", ")}
            </p>
          </div>
        </div>
      )}

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        {[
          { label: "Em estoque", value: items.filter(i => getStockLevel(i) === "full").length, color: "#059669" },
          { label: "Atenção", value: items.filter(i => getStockLevel(i) === "ok").length, color: "#D97706" },
          { label: "Em falta", value: items.filter(i => getStockLevel(i) === "low").length, color: "#DC2626" },
        ].map((s) => (
          <div key={s.label} className="bg-white border border-[#E4E3E0] rounded-[12px] p-4">
            <span className="text-[28px] font-semibold font-mono leading-none block" style={{ color: s.color }}>
              {s.value}
            </span>
            <p className="text-xs text-[#9B9A96] mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Category filter */}
      <div className="flex items-center gap-2 flex-wrap mb-4">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`px-3 py-1 rounded-full text-sm border transition-colors ${
              filter === c
                ? "bg-[#1A1917] text-white border-[#1A1917]"
                : "bg-white text-[#6B6A67] border-[#C8C7C3] hover:border-[#9B9A96]"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Items grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map((item) => {
          const level = getStockLevel(item);
          const ratio = Math.min(item.quantity / item.minimum, 1);

          return (
            <div
              key={item.id}
              className="bg-white border border-[#E4E3E0] rounded-[12px] p-4"
              style={level === "low" ? { borderColor: "#FECACA" } : {}}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div
                    className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{ background: catColors[item.category] || "#9B9A96" }}
                  />
                  <span className="text-sm font-medium text-[#1A1917]">{item.name}</span>
                </div>
                <span className="text-xs text-[#9B9A96] bg-[#F0EFED] rounded-full px-2 py-0.5">
                  {item.category}
                </span>
              </div>

              {/* Quantity control */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => adjustQuantity(item.id, -1)}
                    className="w-6 h-6 rounded-[4px] border border-[#E4E3E0] flex items-center justify-center text-sm text-[#6B6A67] hover:bg-[#F0EFED] transition-colors"
                  >
                    −
                  </button>
                  <span className="text-sm font-mono text-[#1A1917] w-16 text-center">
                    {item.quantity} {item.unit}
                  </span>
                  <button
                    onClick={() => adjustQuantity(item.id, +1)}
                    className="w-6 h-6 rounded-[4px] border border-[#E4E3E0] flex items-center justify-center text-sm text-[#6B6A67] hover:bg-[#F0EFED] transition-colors"
                  >
                    +
                  </button>
                </div>
                <span className="text-xs text-[#9B9A96] font-mono">
                  mín {item.minimum} {item.unit}
                </span>
              </div>

              {/* Stock bar */}
              <div className="h-1.5 w-full bg-[#F0EFED] rounded-full overflow-hidden mb-2">
                <div
                  style={{
                    width: `${ratio * 100}%`,
                    background: stockColors[level],
                    height: "100%",
                    borderRadius: 999,
                    transition: "width 400ms ease-out",
                  }}
                />
              </div>

              <div className="flex items-center justify-between">
                <span
                  className="text-xs font-medium"
                  style={{ color: stockColors[level] }}
                >
                  {level === "low" ? "Abaixo do mínimo" : level === "ok" ? "Atenção" : "Em estoque"}
                </span>
                <span className="text-xs text-[#C8C7C3] font-mono">atualiz. {item.lastUpdated}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
