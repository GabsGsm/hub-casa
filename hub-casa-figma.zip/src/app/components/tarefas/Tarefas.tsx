import { useState, useRef, useEffect } from "react";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { X, ChevronRight } from "lucide-react";

// ── Types ─────────────────────────────────────────────────
interface Task {
  id: string;
  title: string;
  description?: string;
  assignees: string[];
  color: string;
  completed: boolean;
  dayIndex: number;
}

const TASK = "TASK";

// ── Week calculation ──────────────────────────────────────
function getWeek(offset: number): { days: Date[]; label: string } {
  const today = new Date(2026, 2, 14); // March 14, 2026 (Saturday)
  const dayOfWeek = today.getDay(); // 6 = Saturday
  const monday = new Date(today);
  monday.setDate(today.getDate() - ((dayOfWeek + 6) % 7) + offset * 7);

  const days: Date[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    days.push(d);
  }

  const start = days[0].getDate();
  const end = days[6].getDate();
  const month = days[0].toLocaleDateString("pt-BR", { month: "long" });
  return { days, label: `${start}–${end} ${month}` };
}

const dayAbbr = ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"];

// ── Initial task data ─────────────────────────────────────
const initialTasks: Task[] = [
  { id: "t1", title: "Limpar a cozinha", assignees: ["GA"], color: "#7C3AED", completed: true, dayIndex: 0 },
  { id: "t2", title: "Pagar condomínio", assignees: ["GA"], color: "#2563EB", completed: false, dayIndex: 0 },
  { id: "t3", title: "Comprar mantimentos", assignees: ["AA"], color: "#D97706", completed: false, dayIndex: 1 },
  { id: "t4", title: "Regar plantas", assignees: ["AA"], color: "#059669", completed: true, dayIndex: 1 },
  { id: "t5", title: "Reunião com síndico", assignees: ["GA"], color: "#2563EB", completed: false, dayIndex: 2, description: "Pauta: manutenção do elevador" },
  { id: "t6", title: "Organizar garagem", assignees: ["GA", "AA"], color: "#7C3AED", completed: false, dayIndex: 2 },
  { id: "t7", title: "Manutenção da geladeira", assignees: ["GA"], color: "#D97706", completed: true, dayIndex: 3 },
  { id: "t8", title: "Limpar banheiro", assignees: ["AA"], color: "#7C3AED", completed: false, dayIndex: 3 },
  { id: "t9", title: "Pagar conta de luz", assignees: ["GA"], color: "#2563EB", completed: false, dayIndex: 4 },
  { id: "t10", title: "Trocar filtro de água", assignees: ["GA"], color: "#059669", completed: false, dayIndex: 4 },
  { id: "t11", title: "Aspirar sala", assignees: ["AA"], color: "#7C3AED", completed: true, dayIndex: 4 },
  { id: "t12", title: "Fazer compras", assignees: ["AA"], color: "#D97706", completed: false, dayIndex: 5 },
  { id: "t13", title: "Lavar roupa", assignees: ["GA"], color: "#7C3AED", completed: false, dayIndex: 5 },
];

// ── Avatar ────────────────────────────────────────────────
function Avatar({ initials, size = 20 }: { initials: string; size?: number }) {
  return (
    <div
      style={{ width: size, height: size, fontSize: size * 0.4 }}
      className="rounded-full bg-[#1A1917] text-white flex items-center justify-center font-medium flex-shrink-0"
    >
      {initials}
    </div>
  );
}

// ── Task Card ─────────────────────────────────────────────
function TaskCard({
  task,
  onToggle,
  onClick,
}: {
  task: Task;
  onToggle: (id: string) => void;
  onClick: (task: Task) => void;
}) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: TASK,
    item: { id: task.id },
    collect: (m) => ({ isDragging: m.isDragging() }),
  }));

  return (
    <div
      ref={drag as unknown as React.Ref<HTMLDivElement>}
      onClick={() => onClick(task)}
      style={{
        opacity: isDragging ? 0.4 : 1,
        borderLeft: `3px solid ${task.color}`,
        transform: isDragging ? "scale(1.02)" : "scale(1)",
        cursor: isDragging ? "grabbing" : "grab",
        background: task.completed ? "#F8F8F7" : "white",
        borderTop: "1px solid #E4E3E0",
        borderRight: "1px solid #E4E3E0",
        borderBottom: "1px solid #E4E3E0",
        transition: "transform 200ms ease, opacity 150ms ease",
      }}
      className="rounded-[8px] px-3 py-2.5 mb-2 hover:border-[#C8C7C3] select-none"
    >
      <div className="flex items-start justify-between gap-1 mb-2">
        <span
          className={`text-sm leading-snug flex-1 ${
            task.completed ? "line-through text-[#9B9A96] opacity-50" : "text-[#1A1917]"
          }`}
        >
          {task.title}
        </span>
        {task.description && (
          <ChevronRight size={12} className="text-[#9B9A96] flex-shrink-0 mt-0.5" />
        )}
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center -space-x-1">
          {task.assignees.slice(0, 3).map((a) => (
            <Avatar key={a} initials={a} size={20} />
          ))}
          {task.assignees.length > 3 && (
            <div className="w-5 h-5 rounded-full bg-[#F0EFED] text-[#6B6A67] text-[9px] flex items-center justify-center border border-white">
              +{task.assignees.length - 3}
            </div>
          )}
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); onToggle(task.id); }}
          className={`w-4 h-4 rounded-full border flex items-center justify-center transition-colors ${
            task.completed ? "bg-[#7C3AED] border-[#7C3AED]" : "border-[#E4E3E0] hover:border-[#7C3AED]"
          }`}
        >
          {task.completed && (
            <svg width="7" height="5" viewBox="0 0 7 5" fill="none">
              <path d="M1 2.5L2.8 4L6 1" stroke="white" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </button>
      </div>
    </div>
  );
}

// ── Column ────────────────────────────────────────────────
function KanbanColumn({
  dayIndex,
  date,
  tasks,
  isToday,
  onDrop,
  onToggle,
  onTaskClick,
  onAddTask,
}: {
  dayIndex: number;
  date: Date;
  tasks: Task[];
  isToday: boolean;
  onDrop: (taskId: string, toDayIndex: number) => void;
  onToggle: (taskId: string) => void;
  onTaskClick: (task: Task) => void;
  onAddTask: (dayIndex: number, title: string) => void;
}) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: TASK,
    drop: (item: { id: string }) => onDrop(item.id, dayIndex),
    collect: (m) => ({ isOver: m.isOver() }),
  }));

  const [adding, setAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (adding) inputRef.current?.focus();
  }, [adding]);

  function handleAdd() {
    if (newTitle.trim()) {
      onAddTask(dayIndex, newTitle.trim());
    }
    setAdding(false);
    setNewTitle("");
  }

  const completedCount = tasks.filter((t) => t.completed).length;

  return (
    <div
      ref={drop as unknown as React.Ref<HTMLDivElement>}
      className={`flex flex-col min-w-[140px] border-r border-[#F0EFED] last:border-0 px-2 transition-colors ${
        isOver ? "bg-[#F8F8F7]" : ""
      }`}
      style={{ flex: "1 1 140px" }}
    >
      {/* Column header */}
      <div className="py-3 px-1 mb-2">
        {isToday && (
          <div className="w-1 h-1 rounded-full bg-[#1A1917] mb-1" />
        )}
        <p className={`text-xs uppercase tracking-widest mb-0.5 ${isToday ? "text-[#1A1917]" : "text-[#9B9A96]"}`}>
          {dayAbbr[dayIndex]}
        </p>
        <div className="flex items-center gap-1.5">
          <span className={`text-[20px] font-medium leading-none ${isToday ? "text-[#1A1917]" : "text-[#3D3C3A]"}`}>
            {date.getDate()}
          </span>
          {tasks.length > 0 && (
            <span className="text-xs font-mono text-[#6B6A67] bg-[#F0EFED] rounded-full px-1.5 py-0.5">
              {completedCount}/{tasks.length}
            </span>
          )}
        </div>
      </div>

      {/* Tasks */}
      <div className="flex-1 min-h-[80px]">
        {tasks.length === 0 && !adding ? (
          <div className="border border-dashed border-[#E4E3E0] rounded-[8px] flex items-center justify-center py-4 mb-2">
            <span className="text-xs text-[#C8C7C3]">Nenhuma tarefa</span>
          </div>
        ) : (
          tasks.map((t) => (
            <TaskCard
              key={t.id}
              task={t}
              onToggle={onToggle}
              onClick={onTaskClick}
            />
          ))
        )}

        {/* Inline creation */}
        {adding && (
          <div className="bg-white border border-[#2563EB] rounded-[8px] px-3 py-2 mb-2">
            <input
              ref={inputRef}
              type="text"
              placeholder="Nome da tarefa..."
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleAdd();
                if (e.key === "Escape") { setAdding(false); setNewTitle(""); }
              }}
              onBlur={handleAdd}
              className="w-full text-sm text-[#1A1917] placeholder:text-[#C8C7C3] focus:outline-none bg-transparent"
            />
          </div>
        )}
      </div>

      {/* Add button */}
      <button
        onClick={() => setAdding(true)}
        className="text-sm text-[#9B9A96] hover:text-[#6B6A67] hover:bg-[#F8F8F7] transition-colors rounded-[6px] py-1.5 px-1 text-left w-full mt-1"
      >
        + Nova tarefa
      </button>
    </div>
  );
}

// ── Task Detail Drawer ────────────────────────────────────
const colorSwatches = ["#7C3AED", "#2563EB", "#059669", "#D97706", "#DC2626", "#9B9A96", "#1A1917", "#F0EFED"];

function TaskDetailDrawer({
  task,
  days,
  onClose,
  onUpdate,
  onDelete,
}: {
  task: Task | null;
  days: Date[];
  onClose: () => void;
  onUpdate: (id: string, updates: Partial<Task>) => void;
  onDelete: (id: string) => void;
}) {
  if (!task) return null;

  const day = days[task.dayIndex];
  const dayLabel = day
    ? day.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" })
    : "";

  return (
    <>
      <div
        className="fixed inset-0 bg-[#1A1917]/20 z-40 transition-opacity"
        onClick={onClose}
      />
      <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[360px] bg-white border-l border-[#E4E3E0] flex flex-col transition-transform duration-200 ease-out shadow-lg">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E4E3E0]">
          <span className="text-xs text-[#9B9A96] capitalize">{dayLabel}</span>
          <button onClick={onClose} className="text-[#9B9A96] hover:text-[#1A1917] transition-colors">
            <X size={16} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-4">
          {/* Title */}
          <input
            type="text"
            value={task.title}
            onChange={(e) => onUpdate(task.id, { title: e.target.value })}
            className="text-[20px] font-medium text-[#1A1917] focus:outline-none border-b border-transparent focus:border-[#E4E3E0] transition-colors pb-1 bg-transparent w-full"
          />

          {/* Description */}
          <div>
            <label className="block text-xs text-[#9B9A96] mb-1.5">Descrição</label>
            <textarea
              value={task.description || ""}
              onChange={(e) => onUpdate(task.id, { description: e.target.value })}
              placeholder="Adicionar descrição..."
              rows={3}
              className="w-full text-sm text-[#1A1917] placeholder:text-[#C8C7C3] focus:outline-none border border-[#E4E3E0] rounded-[8px] p-3 resize-none focus:border-[#C8C7C3] transition-colors"
            />
          </div>

          {/* Responsáveis */}
          <div>
            <label className="block text-xs text-[#9B9A96] mb-1.5">Responsáveis</label>
            <div className="flex items-center gap-2 flex-wrap">
              {task.assignees.map((a) => (
                <div key={a} className="flex items-center gap-1.5 bg-[#F0EFED] rounded-full pl-0.5 pr-2 py-0.5">
                  <div className="w-5 h-5 rounded-full bg-[#1A1917] flex items-center justify-center text-[9px] text-white font-medium">
                    {a}
                  </div>
                  <span className="text-xs text-[#6B6A67]">{a === "GA" ? "Gabriel" : "Ana"}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Cor */}
          <div>
            <label className="block text-xs text-[#9B9A96] mb-1.5">Cor</label>
            <div className="flex items-center gap-2 flex-wrap">
              {colorSwatches.map((c) => (
                <button
                  key={c}
                  onClick={() => onUpdate(task.id, { color: c })}
                  style={{ background: c }}
                  className={`w-5 h-5 rounded-full transition-transform hover:scale-110 ${
                    task.color === c ? "ring-2 ring-offset-1 ring-[#1A1917]" : ""
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Status */}
          <div className="flex items-center justify-between">
            <label className="text-sm text-[#1A1917]">Concluída</label>
            <button
              onClick={() => onUpdate(task.id, { completed: !task.completed })}
              className={`w-8 h-[18px] rounded-full transition-colors relative ${
                task.completed ? "bg-[#7C3AED]" : "bg-[#C8C7C3]"
              }`}
            >
              <div
                className={`w-3.5 h-3.5 bg-white rounded-full absolute top-0.5 transition-transform duration-150 ${
                  task.completed ? "translate-x-[14px]" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>
        </div>

        {/* Danger zone */}
        <div className="px-5 py-3 border-t border-[#E4E3E0]">
          <button
            onClick={() => { onDelete(task.id); onClose(); }}
            className="text-xs text-[#9B9A96] hover:text-[#DC2626] transition-colors"
          >
            Excluir tarefa
          </button>
        </div>
      </div>
    </>
  );
}

// ── Kanban Board ──────────────────────────────────────────
function KanbanBoard() {
  const [weekOffset, setWeekOffset] = useState(0);
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const { days, label } = getWeek(weekOffset);
  const today = new Date(2026, 2, 14);

  function handleDrop(taskId: string, toDayIndex: number) {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, dayIndex: toDayIndex } : t))
    );
  }

  function handleToggle(taskId: string) {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t))
    );
    if (selectedTask?.id === taskId) {
      setSelectedTask((prev) => prev ? { ...prev, completed: !prev.completed } : null);
    }
  }

  function handleUpdate(id: string, updates: Partial<Task>) {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
    setSelectedTask((prev) => (prev?.id === id ? { ...prev, ...updates } : prev));
  }

  function handleDelete(id: string) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }

  function handleAddTask(dayIndex: number, title: string) {
    const newTask: Task = {
      id: `t${Date.now()}`,
      title,
      assignees: ["GA"],
      color: "#7C3AED",
      completed: false,
      dayIndex,
    };
    setTasks((prev) => [...prev, newTask]);
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-[28px] font-semibold text-[#1A1917] leading-tight">Tarefas</h1>
          <span className="text-sm text-[#9B9A96] font-mono">{label}</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setWeekOffset((w) => w - 1)}
            className="flex items-center gap-1 px-3 py-1.5 text-sm text-[#6B6A67] hover:text-[#1A1917] hover:bg-[#F0EFED] rounded-[6px] transition-colors"
          >
            ← Anterior
          </button>
          <button
            onClick={() => setWeekOffset(0)}
            className="px-3 py-1.5 text-sm text-[#6B6A67] hover:text-[#1A1917] hover:bg-[#F0EFED] rounded-[6px] transition-colors"
          >
            Hoje
          </button>
          <button
            onClick={() => setWeekOffset((w) => w + 1)}
            className="flex items-center gap-1 px-3 py-1.5 text-sm text-[#6B6A67] hover:text-[#1A1917] hover:bg-[#F0EFED] rounded-[6px] transition-colors"
          >
            Próxima →
          </button>
        </div>
      </div>

      {/* Board */}
      <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-x-auto">
        <div className="flex min-w-[700px]" style={{ minHeight: 400 }}>
          {days.map((date, dayIndex) => {
            const isToday =
              date.getDate() === today.getDate() &&
              date.getMonth() === today.getMonth() &&
              date.getFullYear() === today.getFullYear();

            const dayTasks = tasks.filter((t) => t.dayIndex === dayIndex);

            return (
              <KanbanColumn
                key={dayIndex}
                dayIndex={dayIndex}
                date={date}
                tasks={dayTasks}
                isToday={isToday}
                onDrop={handleDrop}
                onToggle={handleToggle}
                onTaskClick={setSelectedTask}
                onAddTask={handleAddTask}
              />
            );
          })}
        </div>
      </div>

      {/* Task Detail Drawer */}
      {selectedTask && (
        <TaskDetailDrawer
          task={selectedTask}
          days={days}
          onClose={() => setSelectedTask(null)}
          onUpdate={handleUpdate}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
}

// ── Export ────────────────────────────────────────────────
export function Tarefas() {
  return (
    <DndProvider backend={HTML5Backend}>
      <KanbanBoard />
    </DndProvider>
  );
}