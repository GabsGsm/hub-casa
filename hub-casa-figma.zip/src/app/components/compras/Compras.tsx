import { useState } from "react";
import { Plus, Check, Trash2 } from "lucide-react";

interface ShoppingItem {
  id: string;
  name: string;
  quantity: string;
  category: string;
  checked: boolean;
  priority: "high" | "normal";
}

const initialItems: ShoppingItem[] = [
  { id: "1", name: "Arroz integral 1kg", quantity: "2 pct", category: "Grãos", checked: false, priority: "normal" },
  { id: "2", name: "Feijão carioca 1kg", quantity: "1 pct", category: "Grãos", checked: false, priority: "normal" },
  { id: "3", name: "Leite integral", quantity: "4 L", category: "Laticínios", checked: true, priority: "normal" },
  { id: "4", name: "Ovos", quantity: "1 dz", category: "Laticínios", checked: false, priority: "high" },
  { id: "5", name: "Frango inteiro", quantity: "2 kg", category: "Carnes", checked: false, priority: "high" },
  { id: "6", name: "Detergente", quantity: "3 un", category: "Limpeza", checked: true, priority: "normal" },
  { id: "7", name: "Papel higiênico", quantity: "1 fardo", category: "Limpeza", checked: false, priority: "high" },
  { id: "8", name: "Shampoo", quantity: "1 un", category: "Higiene", checked: false, priority: "normal" },
];

const categories = ["Todos", "Grãos", "Laticínios", "Carnes", "Limpeza", "Higiene", "Outros"];

const catColors: Record<string, string> = {
  Grãos: "#D97706",
  Laticínios: "#2563EB",
  Carnes: "#DC2626",
  Limpeza: "#059669",
  Higiene: "#7C3AED",
  Outros: "#9B9A96",
};

export function Compras() {
  const [items, setItems] = useState<ShoppingItem[]>(initialItems);
  const [filter, setFilter] = useState("Todos");
  const [newItem, setNewItem] = useState("");
  const [addingItem, setAddingItem] = useState(false);

  const filtered = items.filter((i) => filter === "Todos" || i.category === filter);
  const checkedCount = items.filter((i) => i.checked).length;

  function toggleItem(id: string) {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, checked: !i.checked } : i)));
  }

  function deleteItem(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  function addItem() {
    if (!newItem.trim()) return;
    setItems((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        name: newItem.trim(),
        quantity: "1 un",
        category: "Outros",
        checked: false,
        priority: "normal",
      },
    ]);
    setNewItem("");
    setAddingItem(false);
  }

  const unchecked = filtered.filter((i) => !i.checked);
  const checked = filtered.filter((i) => i.checked);

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[28px] font-semibold text-[#1A1917]">Compras</h1>
          <p className="text-sm text-[#9B9A96] font-mono mt-0.5">
            {checkedCount} / {items.length} itens
          </p>
        </div>
        <button
          onClick={() => setAddingItem(true)}
          className="flex items-center gap-1.5 h-9 px-4 bg-[#1A1917] text-white rounded-[8px] text-sm hover:bg-[#3D3C3A] transition-colors"
        >
          <Plus size={14} />
          Adicionar item
        </button>
      </div>

      {/* Progress */}
      <div className="bg-white border border-[#E4E3E0] rounded-[12px] p-5 mb-5">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-[#6B6A67]">Progresso da lista</span>
          <span className="text-sm font-mono text-[#1A1917]">
            {Math.round((checkedCount / items.length) * 100)}%
          </span>
        </div>
        <div className="h-2 w-full bg-[#F0EFED] rounded-full overflow-hidden">
          <div
            style={{ width: `${(checkedCount / items.length) * 100}%`, transition: "width 400ms ease-out" }}
            className="h-full bg-[#059669] rounded-full"
          />
        </div>
      </div>

      {/* Category filter */}
      <div className="flex items-center gap-2 flex-wrap mb-4">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`px-3 py-1 rounded-full text-sm border transition-colors ${
              filter === c
                ? "bg-[#1A1917] text-white border-[#1A1917]"
                : "bg-white text-[#6B6A67] border-[#C8C7C3] hover:border-[#9B9A96]"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Add item inline */}
      {addingItem && (
        <div className="bg-white border border-[#2563EB] rounded-[8px] px-4 py-3 mb-3 flex items-center gap-3">
          <input
            autoFocus
            type="text"
            placeholder="Nome do item..."
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") addItem();
              if (e.key === "Escape") { setAddingItem(false); setNewItem(""); }
            }}
            className="flex-1 text-sm text-[#1A1917] placeholder:text-[#C8C7C3] focus:outline-none bg-transparent"
          />
          <button onClick={addItem} className="text-sm text-[#2563EB] hover:text-[#1A1917] transition-colors">
            Adicionar
          </button>
        </div>
      )}

      {/* Items list */}
      <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-hidden">
        {/* Unchecked */}
        {unchecked.length > 0 && (
          <div>
            {unchecked.map((item, i) => (
              <div
                key={item.id}
                className={`flex items-center gap-3 px-5 py-3 hover:bg-[#F8F8F7] transition-colors group ${
                  i < unchecked.length - 1 || checked.length > 0 ? "border-b border-[#E4E3E0]" : ""
                }`}
              >
                <button
                  onClick={() => toggleItem(item.id)}
                  className="w-5 h-5 rounded-[4px] border border-[#E4E3E0] flex items-center justify-center flex-shrink-0 hover:border-[#9B9A96] transition-colors"
                />
                <div
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ background: catColors[item.category] || "#9B9A96" }}
                />
                <div className="flex-1 min-w-0">
                  <span className={`text-sm ${item.priority === "high" ? "text-[#1A1917] font-medium" : "text-[#1A1917]"}`}>
                    {item.name}
                  </span>
                  {item.priority === "high" && (
                    <span className="ml-2 text-xs text-[#DC2626] bg-red-50 px-1.5 py-0.5 rounded-full">urgente</span>
                  )}
                </div>
                <span className="text-xs font-mono text-[#9B9A96] flex-shrink-0">{item.quantity}</span>
                <span className="text-xs text-[#9B9A96] bg-[#F0EFED] rounded-full px-2 py-0.5 flex-shrink-0 hidden sm:inline">
                  {item.category}
                </span>
                <button
                  onClick={() => deleteItem(item.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity text-[#9B9A96] hover:text-[#DC2626]"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Checked items */}
        {checked.length > 0 && (
          <div>
            <div className="px-5 py-2 bg-[#F8F8F7] border-b border-[#E4E3E0]">
              <span className="text-xs text-[#9B9A96] uppercase tracking-wide">Marcados ({checked.length})</span>
            </div>
            {checked.map((item, i) => (
              <div
                key={item.id}
                className={`flex items-center gap-3 px-5 py-3 hover:bg-[#F8F8F7] transition-colors group ${
                  i < checked.length - 1 ? "border-b border-[#E4E3E0]" : ""
                }`}
              >
                <button
                  onClick={() => toggleItem(item.id)}
                  className="w-5 h-5 rounded-[4px] bg-[#059669] border border-[#059669] flex items-center justify-center flex-shrink-0"
                >
                  <Check size={12} className="text-white" />
                </button>
                <div className="w-2 h-2 rounded-full flex-shrink-0 bg-[#C8C7C3]" />
                <span className="text-sm line-through text-[#9B9A96] flex-1 opacity-50">{item.name}</span>
                <span className="text-xs font-mono text-[#C8C7C3] flex-shrink-0">{item.quantity}</span>
                <button
                  onClick={() => deleteItem(item.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity text-[#9B9A96] hover:text-[#DC2626]"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        )}

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-sm text-[#9B9A96]">Nenhum item nesta categoria</p>
          </div>
        )}
      </div>
    </div>
  );
}
