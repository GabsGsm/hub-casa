import { useState } from "react";
import { Outlet, NavLink, useLocation } from "react-router";
import {
  LayoutDashboard,
  CreditCard,
  CheckSquare,
  CalendarDays,
  ShoppingCart,
  Package,
  Bell,
  Settings,
  Home,
  X,
} from "lucide-react";

interface NavItem {
  label: string;
  path: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  color?: string;
  mobileVisible: boolean;
}

const navItems: NavItem[] = [
  { label: "Home", path: "/", icon: LayoutDashboard, mobileVisible: true },
  { label: "Financeiro", path: "/financeiro", icon: CreditCard, color: "#2563EB", mobileVisible: true },
  { label: "Tarefas", path: "/tarefas", icon: CheckSquare, color: "#7C3AED", mobileVisible: true },
  { label: "Agenda", path: "/agenda", icon: CalendarDays, color: "#D97706", mobileVisible: true },
  { label: "Compras", path: "/compras", icon: ShoppingCart, mobileVisible: true },
  { label: "Dispensa", path: "/dispensa", icon: Package, mobileVisible: false },
];

function Avatar({ name, size = 28 }: { name: string; size?: number }) {
  const initials = name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div
      style={{ width: size, height: size, fontSize: size * 0.4 }}
      className="rounded-full bg-[#1A1917] text-white flex items-center justify-center font-medium flex-shrink-0"
    >
      {initials}
    </div>
  );
}

function SidebarNavItem({ item, collapsed }: { item: NavItem; collapsed?: boolean }) {
  const location = useLocation();
  const isActive = item.path === "/" ? location.pathname === "/" : location.pathname.startsWith(item.path);
  const activeColor = item.color || "#1A1917";

  return (
    <NavLink
      to={item.path}
      className={`
        flex items-center gap-2 rounded-[6px] transition-all duration-150 cursor-pointer select-none
        ${collapsed ? "justify-center px-0 py-2 w-full" : "px-3 py-2"}
        ${isActive ? "bg-[#F0EFED]" : "hover:bg-[#F8F8F7]"}
      `}
      style={
        isActive && !collapsed
          ? { borderLeft: `2px solid ${activeColor}`, paddingLeft: 10 }
          : collapsed
          ? {}
          : { borderLeft: "2px solid transparent" }
      }
    >
      <item.icon
        size={16}
        style={{ color: isActive ? activeColor : "#9B9A96" }}
        className="flex-shrink-0"
      />
      {!collapsed && (
        <span
          className="text-sm"
          style={{ color: isActive ? "#1A1917" : "#6B6A67" }}
        >
          {item.label}
        </span>
      )}
    </NavLink>
  );
}

export function Layout() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const location = useLocation();

  const currentPage = navItems.find((item) =>
    item.path === "/" ? location.pathname === "/" : location.pathname.startsWith(item.path)
  );

  return (
    <div className="flex h-screen overflow-hidden bg-[#F8F8F7]">
      {/* ── Desktop Sidebar ──────────────────────────────── */}
      <aside className="hidden lg:flex flex-col w-[220px] flex-shrink-0 bg-white border-r border-[#E4E3E0] h-full">
        {/* Logo */}
        <div className="flex items-center gap-2 px-4 h-14 border-b border-[#E4E3E0]">
          <div className="w-7 h-7 bg-[#1A1917] rounded-[6px] flex items-center justify-center">
            <Home size={14} className="text-white" />
          </div>
          <span className="text-[16px] font-medium text-[#1A1917]">Hub Casa</span>
        </div>

        {/* Nav Items */}
        <nav className="flex-1 px-2 py-3 flex flex-col gap-0.5 overflow-y-auto">
          {navItems.map((item) => (
            <SidebarNavItem key={item.path} item={item} />
          ))}
        </nav>

        {/* User */}
        <div className="px-3 py-3 border-t border-[#E4E3E0] flex items-center gap-2">
          <Avatar name="Gabriel Alves" size={28} />
          <div className="flex-1 min-w-0">
            <p className="text-sm text-[#1A1917] truncate">Gabriel Alves</p>
            <p className="text-xs text-[#9B9A96] truncate">Casa dos Jardins</p>
          </div>
        </div>
      </aside>

      {/* ── Tablet Icon Rail ─────────────────────────────── */}
      <aside className="hidden md:flex lg:hidden flex-col w-14 flex-shrink-0 bg-white border-r border-[#E4E3E0] h-full items-center py-3 gap-1">
        <button
          onClick={() => setDrawerOpen(true)}
          className="w-9 h-9 bg-[#1A1917] rounded-[6px] flex items-center justify-center mb-2"
        >
          <Home size={14} className="text-white" />
        </button>
        {navItems.map((item) => {
          const isActive =
            item.path === "/" ? location.pathname === "/" : location.pathname.startsWith(item.path);
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={`w-9 h-9 rounded-[6px] flex items-center justify-center transition-all duration-150
                ${isActive ? "bg-[#F0EFED]" : "hover:bg-[#F8F8F7]"}`}
            >
              <item.icon
                size={16}
                style={{ color: isActive ? (item.color || "#1A1917") : "#9B9A96" }}
              />
            </NavLink>
          );
        })}
      </aside>

      {/* ── Tablet Overlay Drawer ────────────────────────── */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex md:flex lg:hidden">
          <div
            className="absolute inset-0 bg-[#1A1917]/20"
            onClick={() => setDrawerOpen(false)}
          />
          <div className="relative w-[220px] bg-white h-full flex flex-col border-r border-[#E4E3E0] shadow-lg">
            <div className="flex items-center justify-between px-4 h-14 border-b border-[#E4E3E0]">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-[#1A1917] rounded-[6px] flex items-center justify-center">
                  <Home size={14} className="text-white" />
                </div>
                <span className="text-[16px] font-medium text-[#1A1917]">Hub Casa</span>
              </div>
              <button onClick={() => setDrawerOpen(false)} className="text-[#9B9A96] hover:text-[#1A1917]">
                <X size={16} />
              </button>
            </div>
            <nav className="flex-1 px-2 py-3 flex flex-col gap-0.5">
              {navItems.map((item) => (
                <div key={item.path} onClick={() => setDrawerOpen(false)}>
                  <SidebarNavItem item={item} />
                </div>
              ))}
            </nav>
            <div className="px-3 py-3 border-t border-[#E4E3E0] flex items-center gap-2">
              <Avatar name="Gabriel Alves" size={28} />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-[#1A1917] truncate">Gabriel Alves</p>
                <p className="text-xs text-[#9B9A96] truncate">Casa dos Jardins</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Main Content ─────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Bar (desktop/tablet) */}
        <header className="hidden md:flex h-14 bg-white border-b border-[#E4E3E0] items-center px-6 gap-3 flex-shrink-0">
          <span className="flex-1 text-sm text-[#9B9A96]">
            {currentPage?.label || "Hub Casa"}
          </span>
          <button className="w-8 h-8 rounded-[6px] flex items-center justify-center hover:bg-[#F0EFED] transition-colors">
            <Bell size={16} className="text-[#9B9A96]" />
          </button>
          <button className="w-8 h-8 rounded-[6px] flex items-center justify-center hover:bg-[#F0EFED] transition-colors">
            <Settings size={16} className="text-[#9B9A96]" />
          </button>
        </header>

        {/* Mobile Top Bar */}
        <header className="flex md:hidden h-[52px] bg-white border-b border-[#E4E3E0] items-center px-4 flex-shrink-0">
          <span className="flex-1 text-[16px] font-medium text-[#1A1917]">
            {currentPage?.label || "Hub Casa"}
          </span>
          <Avatar name="Gabriel Alves" size={32} />
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-[1200px] mx-auto w-full p-6 pb-24 md:pb-6">
            <Outlet />
          </div>
        </main>
      </div>

      {/* ── Mobile Bottom Nav ────────────────────────────── */}
      <nav className="fixed bottom-0 inset-x-0 md:hidden bg-white border-t border-[#E4E3E0] flex items-center h-16 z-40 safe-area-pb">
        {navItems.filter((item) => item.mobileVisible).map((item) => {
          const isActive =
            item.path === "/" ? location.pathname === "/" : location.pathname.startsWith(item.path);
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2"
            >
              <item.icon
                size={20}
                style={{ color: isActive ? (item.color || "#1A1917") : "#9B9A96" }}
              />
              {isActive && (
                <span
                  className="text-xs font-medium"
                  style={{ color: item.color || "#1A1917" }}
                >
                  {item.label}
                </span>
              )}
            </NavLink>
          );
        })}
      </nav>
    </div>
  );
}