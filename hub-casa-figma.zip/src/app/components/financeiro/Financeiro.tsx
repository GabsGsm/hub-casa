import { useState } from "react";
import { X, Plus, ChevronDown } from "lucide-react";

// ── Helpers ──────────────────────────────────────────────
function fmt(n: number) {
  return n.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function ProgressBar({ value, max, height = 8 }: { value: number; max: number; height?: number }) {
  const pct = Math.min((value / max) * 100, 100);
  const over = value > max;
  return (
    <div style={{ height }} className="w-full rounded-full bg-[#F0EFED] overflow-hidden">
      <div
        style={{
          width: `${pct}%`,
          height: "100%",
          background: over ? "#DC2626" : "#2563EB",
          borderRadius: height,
          transition: "width 400ms ease-out",
        }}
      />
    </div>
  );
}

// ── Data ─────────────────────────────────────────────────
const ciclosData = [
  { label: "Dia 10", total: 539, paid: 89, pending: 450, status: "Ativo" },
  { label: "Dia 15", total: 1906.18, paid: 1436.65, pending: 469.53, status: "Ativo" },
  { label: "Dia 25", total: 1250, paid: 812, pending: 438, status: "Futuro" },
];

type LancStatus = "Pago" | "Aberto" | "Impossibilitado";
interface Lancamento {
  id: string;
  desc: string;
  cat: string;
  amount: number;
  due: string;
  ciclo: string;
  status: LancStatus;
  recorrente?: boolean;
  parcela?: string;
}

const lancamentos: Lancamento[] = [
  { id: "1", desc: "Netflix", cat: "Assinatura", amount: -39.9, due: "15/03", ciclo: "Dia 15", status: "Aberto", recorrente: true },
  { id: "2", desc: "Condomínio", cat: "Moradia", amount: -850, due: "10/03", ciclo: "Dia 10", status: "Pago" },
  { id: "3", desc: "Internet Vivo", cat: "Serviços", amount: -99.9, due: "15/03", ciclo: "Dia 15", status: "Aberto", recorrente: true },
  { id: "4", desc: "Conta de Luz", cat: "Moradia", amount: -180, due: "25/03", ciclo: "Dia 25", status: "Aberto" },
  { id: "5", desc: "Salário", cat: "Renda", amount: 4500, due: "05/03", ciclo: "Sem data", status: "Pago" },
  { id: "6", desc: "Supermercado", cat: "Alimentação", amount: -287.5, due: "12/03", ciclo: "Sem data", status: "Pago" },
  { id: "7", desc: "Parcela do Sofá", cat: "Móveis", amount: -199.9, due: "15/03", ciclo: "Dia 15", status: "Aberto", parcela: "2 de 3 parcelas" },
  { id: "8", desc: "Plano de Saúde", cat: "Saúde", amount: -429.73, due: "10/03", ciclo: "Dia 10", status: "Impossibilitado", recorrente: true },
];

// ── Status Pill ───────────────────────────────────────────
const statusConfig: Record<LancStatus, { bg: string; text: string; label: string }> = {
  Pago: { bg: "#F0FDF4", text: "#15803D", label: "Pago" },
  Aberto: { bg: "#FFFBEB", text: "#B45309", label: "Aberto" },
  Impossibilitado: { bg: "#F0EFED", text: "#6B6A67", label: "Impossibilitado" },
};

function StatusPill({ status }: { status: LancStatus }) {
  const s = statusConfig[status];
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-full text-xs"
      style={{ background: s.bg, color: s.text }}
    >
      {s.label}
    </span>
  );
}

function CyclePill({ ciclo }: { ciclo: string }) {
  const isSemData = ciclo === "Sem data";
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-mono"
      style={isSemData ? { background: "#F0EFED", color: "#6B6A67" } : { background: "#EFF6FF", color: "#2563EB" }}
    >
      {ciclo}
    </span>
  );
}

// ── Novo Lançamento Drawer ────────────────────────────────
const tipoOptions = ["Gasto", "Ganho", "Dívida", "Empréstimo", "Afiado"];
const categorias = ["Alimentação", "Moradia", "Saúde", "Transporte", "Lazer", "Assinatura", "Serviços", "Outros"];
const cicloOptions = ["Dia 10", "Dia 15", "Dia 25", "Sem data"];
const recorrenciaOptions = ["Mensal", "Anual", "Diária", "Fixa"];

interface DrawerState {
  titulo: string;
  valor: string;
  tipo: string;
  categoria: string;
  vencimento: string;
  ciclo: string;
  recorrente: boolean;
  parcelas: string;
  recorrencia: string;
}

function NovoLancamentoDrawer({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<DrawerState>({
    titulo: "",
    valor: "",
    tipo: "Gasto",
    categoria: "",
    vencimento: "",
    ciclo: "Dia 15",
    recorrente: false,
    parcelas: "",
    recorrencia: "Mensal",
  });

  function set(key: keyof DrawerState, val: string | boolean) {
    setForm((f) => ({ ...f, [key]: val }));
  }

  return (
    <>
      {/* Overlay */}
      {open && (
        <div
          className="fixed inset-0 bg-[#1A1917]/20 z-40 transition-opacity duration-200"
          onClick={onClose}
        />
      )}
      {/* Drawer */}
      <div
        className={`fixed inset-y-0 right-0 z-50 bg-white flex flex-col
          w-full sm:w-[400px] transition-transform duration-200 ease-out
          border-l border-[#E4E3E0]
          ${open ? "translate-x-0" : "translate-x-full"}`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E4E3E0]">
          <span className="text-[16px] font-medium text-[#1A1917]">Novo lançamento</span>
          <button onClick={onClose} className="text-[#9B9A96] hover:text-[#1A1917] transition-colors">
            <X size={16} />
          </button>
        </div>

        {/* Form */}
        <div className="flex-1 overflow-y-auto px-5 py-5 flex flex-col gap-4">
          {/* Título */}
          <div>
            <label className="block text-xs text-[#6B6A67] mb-1.5">Título</label>
            <input
              type="text"
              placeholder="Ex: Conta de luz"
              value={form.titulo}
              onChange={(e) => set("titulo", e.target.value)}
              className="w-full h-9 border border-[#E4E3E0] rounded-[8px] px-3 text-sm text-[#1A1917] placeholder:text-[#9B9A96] focus:outline-none focus:border-[#1A1917] transition-colors"
            />
          </div>

          {/* Valor */}
          <div>
            <label className="block text-xs text-[#6B6A67] mb-1.5">Valor</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#9B9A96] font-mono">R$</span>
              <input
                type="number"
                placeholder="0,00"
                value={form.valor}
                onChange={(e) => set("valor", e.target.value)}
                className="w-full h-9 border border-[#E4E3E0] rounded-[8px] pl-9 pr-3 text-sm font-mono text-[#1A1917] placeholder:text-[#9B9A96] focus:outline-none focus:border-[#1A1917] transition-colors"
              />
            </div>
          </div>

          {/* Tipo — Segmented Control */}
          <div>
            <label className="block text-xs text-[#6B6A67] mb-1.5">Tipo</label>
            <div className="flex border border-[#E4E3E0] rounded-[8px] overflow-hidden">
              {tipoOptions.map((t) => (
                <button
                  key={t}
                  onClick={() => set("tipo", t)}
                  className={`flex-1 py-1.5 text-xs transition-colors ${
                    form.tipo === t
                      ? "bg-[#1A1917] text-white"
                      : "bg-white text-[#6B6A67] hover:bg-[#F8F8F7]"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Categoria */}
          <div>
            <label className="block text-xs text-[#6B6A67] mb-1.5">Categoria</label>
            <div className="relative">
              <select
                value={form.categoria}
                onChange={(e) => set("categoria", e.target.value)}
                className="w-full h-9 border border-[#E4E3E0] rounded-[8px] px-3 text-sm text-[#1A1917] appearance-none bg-white focus:outline-none focus:border-[#1A1917] transition-colors"
              >
                <option value="">Selecionar categoria</option>
                {categorias.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9B9A96] pointer-events-none" />
            </div>
          </div>

          {/* Vencimento */}
          <div>
            <label className="block text-xs text-[#6B6A67] mb-1.5">Vencimento</label>
            <input
              type="date"
              value={form.vencimento}
              onChange={(e) => set("vencimento", e.target.value)}
              className="w-full h-9 border border-[#E4E3E0] rounded-[8px] px-3 text-sm font-mono text-[#1A1917] focus:outline-none focus:border-[#1A1917] transition-colors"
            />
          </div>

          {/* Ciclo */}
          <div>
            <label className="block text-xs text-[#6B6A67] mb-1.5">Ciclo</label>
            <div className="relative">
              <select
                value={form.ciclo}
                onChange={(e) => set("ciclo", e.target.value)}
                className="w-full h-9 border border-[#E4E3E0] rounded-[8px] px-3 text-sm text-[#1A1917] appearance-none bg-white focus:outline-none focus:border-[#1A1917] transition-colors"
              >
                {cicloOptions.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9B9A96] pointer-events-none" />
            </div>
          </div>

          {/* Recorrente toggle */}
          <div className="flex items-center justify-between">
            <label className="text-sm text-[#1A1917]">Recorrente</label>
            <button
              onClick={() => set("recorrente", !form.recorrente)}
              className={`w-8 h-[18px] rounded-full transition-colors relative ${
                form.recorrente ? "bg-[#1A1917]" : "bg-[#C8C7C3]"
              }`}
            >
              <div
                className={`w-3.5 h-3.5 bg-white rounded-full absolute top-0.5 transition-transform duration-150 ${
                  form.recorrente ? "translate-x-[14px]" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>

          {/* Conditional: Parcelas or Recorrência */}
          {!form.recorrente ? (
            <div>
              <label className="block text-xs text-[#6B6A67] mb-1.5">Parcelas</label>
              <input
                type="number"
                placeholder="1"
                value={form.parcelas}
                onChange={(e) => set("parcelas", e.target.value)}
                className="w-full h-9 border border-[#E4E3E0] rounded-[8px] px-3 text-sm font-mono text-[#1A1917] placeholder:text-[#9B9A96] focus:outline-none focus:border-[#1A1917] transition-colors"
              />
            </div>
          ) : (
            <div>
              <label className="block text-xs text-[#6B6A67] mb-1.5">Recorrência</label>
              <div className="relative">
                <select
                  value={form.recorrencia}
                  onChange={(e) => set("recorrencia", e.target.value)}
                  className="w-full h-9 border border-[#E4E3E0] rounded-[8px] px-3 text-sm text-[#1A1917] appearance-none bg-white focus:outline-none focus:border-[#1A1917] transition-colors"
                >
                  {recorrenciaOptions.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9B9A96] pointer-events-none" />
              </div>
            </div>
          )}

          {/* Responsáveis */}
          <div>
            <label className="block text-xs text-[#6B6A67] mb-1.5">Responsáveis</label>
            <div className="flex items-center gap-2 flex-wrap">
              {["GA", "AA"].map((initials) => (
                <div
                  key={initials}
                  className="flex items-center gap-1.5 bg-[#F0EFED] rounded-full pl-0.5 pr-2 py-0.5"
                >
                  <div className="w-5 h-5 rounded-full bg-[#1A1917] flex items-center justify-center text-[9px] text-white font-medium">
                    {initials}
                  </div>
                  <span className="text-xs text-[#6B6A67]">{initials === "GA" ? "Gabriel" : "Ana"}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-[#E4E3E0] flex items-center gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm text-[#6B6A67] hover:text-[#1A1917] transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={() => { onSave(); onClose(); }}
            className="flex-1 h-9 bg-[#1A1917] text-white rounded-[8px] text-sm hover:bg-[#3D3C3A] transition-colors"
          >
            Salvar
          </button>
        </div>
      </div>
    </>
  );
}

// ── Tab: Visão Geral ──────────────────────────────────────
function VisaoGeral() {
  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {ciclosData.map((c) => {
          const over = c.paid > c.total;
          return (
            <div
              key={c.label}
              className={`bg-white rounded-[12px] p-5 transition-colors ${
                over ? "border border-[#DC2626]" : "border border-[#E4E3E0]"
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-[#6B6A67]">Ciclo · {c.label}</span>
                <div className="flex items-center gap-1">
                  <div
                    className="w-1.5 h-1.5 rounded-full"
                    style={{ background: c.status === "Ativo" ? "#059669" : "#9B9A96" }}
                  />
                  <span className="text-xs text-[#6B6A67]">{c.status}</span>
                </div>
              </div>
              <p className="text-[38px] font-semibold font-mono text-[#2563EB] leading-none mb-3">
                R$ {fmt(c.total)}
              </p>
              <div className="border-t border-[#E4E3E0] pt-3 mb-3 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-sm text-[#6B6A67]">Pago</span>
                  <span className="text-sm font-mono text-[#059669]">R$ {fmt(c.paid)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-[#6B6A67]">Pendente</span>
                  <span className="text-sm font-mono text-[#D97706]">R$ {fmt(c.pending)}</span>
                </div>
              </div>
              <ProgressBar value={c.paid} max={c.total} height={8} />
            </div>
          );
        })}
        {/* Sem data card */}
        <div className="bg-white border border-[#E4E3E0] rounded-[12px] p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-[#6B6A67]">Sem data fixo</span>
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-[#9B9A96]" />
              <span className="text-xs text-[#6B6A67]">Flexível</span>
            </div>
          </div>
          <p className="text-[38px] font-semibold font-mono text-[#9B9A96] leading-none mb-3">
            R$ {fmt(387.5)}
          </p>
          <div className="border-t border-[#E4E3E0] pt-3 mb-3 space-y-1.5">
            <div className="flex justify-between">
              <span className="text-sm text-[#6B6A67]">Pago</span>
              <span className="text-sm font-mono text-[#059669]">R$ {fmt(287.5)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-[#6B6A67]">Pendente</span>
              <span className="text-sm font-mono text-[#D97706]">R$ {fmt(100)}</span>
            </div>
          </div>
          <ProgressBar value={287.5} max={387.5} height={8} />
        </div>
      </div>
    </div>
  );
}

// ── Tab: Lançamentos ──────────────────────────────────────
type FilterType = "Todos" | "Pago" | "Pendente" | "Recorrente" | "Parcelado";
const filters: FilterType[] = ["Todos", "Pago", "Pendente", "Recorrente", "Parcelado"];

function Lancamentos({ onNovo }: { onNovo: () => void }) {
  const [activeFilter, setActiveFilter] = useState<FilterType>("Todos");
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  const filtered = lancamentos.filter((l) => {
    if (activeFilter === "Todos") return true;
    if (activeFilter === "Pago") return l.status === "Pago";
    if (activeFilter === "Pendente") return l.status === "Aberto";
    if (activeFilter === "Recorrente") return l.recorrente;
    if (activeFilter === "Parcelado") return !!l.parcela;
    return true;
  });

  const total = filtered.reduce((sum, l) => sum + l.amount, 0);

  return (
    <div>
      {/* Filter row */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
        <div className="flex items-center gap-2 flex-wrap">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3 py-1 rounded-full text-sm border transition-colors ${
                activeFilter === f
                  ? "bg-[#1A1917] text-white border-[#1A1917]"
                  : "bg-white text-[#6B6A67] border-[#C8C7C3] hover:border-[#9B9A96]"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <button
          onClick={onNovo}
          className="flex items-center gap-1.5 h-9 px-4 bg-[#1A1917] text-white rounded-[8px] text-sm hover:bg-[#3D3C3A] transition-colors"
        >
          <Plus size={14} />
          Novo lançamento
        </button>
      </div>

      {/* Table */}
      <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-hidden">
        {/* Table header */}
        <div className="hidden md:grid grid-cols-[2fr_1fr_1fr_1fr_1fr_32px] gap-4 px-5 py-3 border-b border-[#E4E3E0] bg-[#F8F8F7]">
          {["Descrição", "Valor", "Vencimento", "Ciclo", "Status", ""].map((h) => (
            <span key={h} className="text-xs text-[#9B9A96] uppercase tracking-wide">{h}</span>
          ))}
        </div>

        {/* Rows */}
        {filtered.map((l) => (
          <div
            key={l.id}
            className="grid grid-cols-1 md:grid-cols-[2fr_1fr_1fr_1fr_1fr_32px] gap-2 md:gap-4 px-5 border-b border-[#E4E3E0] last:border-0 hover:bg-[#F8F8F7] transition-colors cursor-pointer"
            style={{ minHeight: 48, alignItems: "center", padding: "10px 20px" }}
            onMouseEnter={() => setHoveredRow(l.id)}
            onMouseLeave={() => setHoveredRow(null)}
          >
            {/* Descrição */}
            <div>
              <p className="text-sm text-[#1A1917]">{l.desc}</p>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                <span className="text-xs text-[#6B6A67] bg-[#F0EFED] rounded-full px-2 py-0.5">{l.cat}</span>
                {l.parcela && (
                  <span className="text-xs text-[#9B9A96] font-mono">{l.parcela}</span>
                )}
              </div>
            </div>
            {/* Valor */}
            <span
              className="text-sm font-mono text-right md:text-left"
              style={{ color: l.amount > 0 ? "#059669" : "#1A1917" }}
            >
              {l.amount > 0 ? "+" : ""}R$ {fmt(Math.abs(l.amount))}
            </span>
            {/* Vencimento */}
            <span className="text-sm font-mono text-[#6B6A67]">{l.due}</span>
            {/* Ciclo */}
            <div>
              <CyclePill ciclo={l.ciclo} />
            </div>
            {/* Status */}
            <div>
              <StatusPill status={l.status} />
            </div>
            {/* Actions */}
            <div className={`transition-opacity ${hoveredRow === l.id ? "opacity-100" : "opacity-0"}`}>
              <button className="text-[#9B9A96] hover:text-[#1A1917] text-lg leading-none">···</button>
            </div>
          </div>
        ))}

        {/* Footer total */}
        <div className="grid grid-cols-1 md:grid-cols-[2fr_1fr_1fr_1fr_1fr_32px] gap-4 px-5 py-3 border-t-2 border-[#E4E3E0] bg-[#F8F8F7]">
          <span className="text-sm font-medium text-[#1A1917]">Total</span>
          <span
            className="text-sm font-medium font-mono"
            style={{ color: total >= 0 ? "#059669" : "#1A1917" }}
          >
            {total >= 0 ? "+" : ""}R$ {fmt(Math.abs(total))}
          </span>
          <span />
          <span />
          <span />
          <span />
        </div>
      </div>
    </div>
  );
}

// ── Ciclos Tab (simplified) ───────────────────────────────
function CiclosTab() {
  return (
    <div className="space-y-3">
      {[...ciclosData, { label: "Sem data", total: 387.5, paid: 287.5, pending: 100, status: "Flexível" }].map((c) => (
        <div key={c.label} className="bg-white border border-[#E4E3E0] rounded-[12px] p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[16px] font-medium text-[#1A1917]">Ciclo · {c.label}</h3>
            <span className="text-sm font-mono text-[#2563EB]">R$ {fmt(c.total)}</span>
          </div>
          <ProgressBar value={c.paid} max={c.total} height={8} />
          <div className="flex justify-between mt-3">
            <span className="text-xs text-[#9B9A96]">R$ {fmt(c.paid)} pagos</span>
            <span className="text-xs text-[#9B9A96]">R$ {fmt(c.pending)} pendentes</span>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Main Financeiro ───────────────────────────────────────
type Tab = "Visão Geral" | "Lançamentos" | "Ciclos" | "Histórico";
const tabs: Tab[] = ["Visão Geral", "Lançamentos", "Ciclos", "Histórico"];

export function Financeiro() {
  const [activeTab, setActiveTab] = useState<Tab>("Visão Geral");
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <div>
      {/* Header */}
      <div className="mb-5">
        <h1 className="text-[28px] font-semibold text-[#1A1917] mb-4">Financeiro</h1>

        {/* Tabs */}
        <div className="flex items-center border-b border-[#E4E3E0] gap-1">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 pb-3 text-sm transition-colors relative ${
                activeTab === t ? "text-[#1A1917]" : "text-[#9B9A96] hover:text-[#6B6A67]"
              }`}
            >
              {t}
              {activeTab === t && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#1A1917] rounded-full" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === "Visão Geral" && <VisaoGeral />}
      {activeTab === "Lançamentos" && <Lancamentos onNovo={() => setDrawerOpen(true)} />}
      {activeTab === "Ciclos" && <CiclosTab />}
      {activeTab === "Histórico" && (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <p className="text-sm text-[#9B9A96]">Histórico em desenvolvimento</p>
          <p className="text-xs text-[#C8C7C3] mt-1">Em breve disponível</p>
        </div>
      )}

      {/* Novo Lançamento Drawer */}
      <NovoLancamentoDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onSave={() => setDrawerOpen(false)}
      />
    </div>
  );
}
