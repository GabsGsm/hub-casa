import { Bell, Settings } from "lucide-react";

// ── Helpers ──────────────────────────────────────────────
function fmt(n: number) {
  return n.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function Avatar({ initials, size = 20, bg = "#1A1917" }: { initials: string; size?: number; bg?: string }) {
  return (
    <div
      style={{ width: size, height: size, fontSize: size * 0.42, background: bg }}
      className="rounded-full text-white flex items-center justify-center font-medium flex-shrink-0"
    >
      {initials}
    </div>
  );
}

function ProgressBar({
  value,
  max,
  height = 4,
  color = "#2563EB",
  animate = true,
}: {
  value: number;
  max: number;
  height?: number;
  color?: string;
  animate?: boolean;
}) {
  const pct = Math.min((value / max) * 100, 100);
  const overBudget = value > max;
  return (
    <div
      style={{ height }}
      className="w-full rounded-full bg-[#F0EFED] overflow-hidden"
    >
      <div
        style={{
          width: `${pct}%`,
          height: "100%",
          background: overBudget ? "#DC2626" : color,
          transition: animate ? "width 400ms ease-out" : undefined,
          borderRadius: height,
        }}
      />
    </div>
  );
}

function RingChart({ value, max, color }: { value: number; max: number; color: string }) {
  const r = 16;
  const circ = 2 * Math.PI * r;
  const fill = (value / max) * circ;
  return (
    <svg width="40" height="40" viewBox="0 0 40 40">
      <circle cx="20" cy="20" r={r} fill="none" stroke="#F0EFED" strokeWidth="3" />
      <circle
        cx="20" cy="20" r={r} fill="none"
        stroke={color} strokeWidth="3"
        strokeDasharray={`${fill} ${circ}`}
        strokeLinecap="round"
        transform="rotate(-90 20 20)"
        style={{ transition: "stroke-dasharray 400ms ease-out" }}
      />
    </svg>
  );
}

// ── Data ─────────────────────────────────────────────────
const ciclos = [
  { label: "Dia 10", paid: 89, pending: 450, total: 539 },
  { label: "Dia 15", paid: 1436.65, pending: 469.53, total: 1906.18 },
  { label: "Dia 25", paid: 812, pending: 438, total: 1250 },
];

const lancamentos = [
  { id: "1", desc: "Netflix", cat: "Assinatura", amount: -39.9, date: "14 mar", color: "#7C3AED" },
  { id: "2", desc: "Salário", cat: "Renda", amount: 4500, date: "13 mar", color: "#059669" },
  { id: "3", desc: "Supermercado", cat: "Alimentação", amount: -287.5, date: "12 mar", color: "#D97706" },
  { id: "4", desc: "Conta de Luz", cat: "Moradia", amount: -180, date: "11 mar", color: "#2563EB" },
  { id: "5", desc: "Internet", cat: "Serviços", amount: -99.9, date: "10 mar", color: "#9B9A96" },
];

const tarefasHoje = [
  { id: "1", title: "Pagar conta de luz", done: true, assignee: "GA" },
  { id: "2", title: "Fazer compras no mercado", done: false, assignee: "AA" },
  { id: "3", title: "Limpar banheiro", done: false, assignee: "GA" },
  { id: "4", title: "Organizar dispensa", done: true, assignee: "AA" },
  { id: "5", title: "Verificar filtro de água", done: false, assignee: "GA" },
];

const compromissos = [
  { time: "14:30", title: "Reunião com síndico" },
  { time: "16:00", title: "Manutenção da geladeira" },
  { time: "19:00", title: "Jantar com a família" },
];

// ── Stat Card ─────────────────────────────────────────────
function StatCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-white border border-[#E4E3E0] rounded-[12px] p-5 ${className}`}>
      {children}
    </div>
  );
}

// ── Dashboard ─────────────────────────────────────────────
export function Dashboard() {
  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";

  const dateStr = now.toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="flex flex-col gap-6">
      {/* ── Greeting Row ── */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-[28px] font-semibold text-[#1A1917] leading-tight">
            {greeting}, Gabriel
          </h1>
          <p className="text-sm text-[#9B9A96] font-mono mt-1 capitalize">{dateStr}</p>
        </div>
        <div className="hidden md:flex items-center gap-1">
          <button className="w-8 h-8 rounded-[6px] flex items-center justify-center hover:bg-[#F0EFED] transition-colors">
            <Bell size={16} className="text-[#9B9A96]" />
          </button>
          <button className="w-8 h-8 rounded-[6px] flex items-center justify-center hover:bg-[#F0EFED] transition-colors">
            <Settings size={16} className="text-[#9B9A96]" />
          </button>
        </div>
      </div>

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Ciclo Ativo */}
        <StatCard>
          <p className="text-xs text-[#9B9A96] uppercase tracking-wide mb-2">Ciclo Ativo</p>
          <div className="flex items-end justify-between mb-2">
            <span className="text-[28px] font-semibold font-mono text-[#2563EB] leading-none">
              R$ 1.250
            </span>
            <span className="text-xs text-[#9B9A96] font-mono mb-1">Dia 25</span>
          </div>
          <ProgressBar value={812} max={1250} height={4} />
          <p className="text-xs text-[#9B9A96] font-mono mt-2">
            R$ 812 pagos · R$ 438 pendentes
          </p>
        </StatCard>

        {/* A Pagar */}
        <StatCard>
          <p className="text-xs text-[#9B9A96] uppercase tracking-wide mb-2">A Pagar</p>
          <span className="text-[28px] font-semibold font-mono text-[#1A1917] leading-none block mb-2">
            R$ {fmt(469.53)}
          </span>
          <p className="text-xs font-mono" style={{ color: "#DC2626" }}>
            2 contas · vence hoje
          </p>
        </StatCard>

        {/* Tarefas */}
        <StatCard className="flex flex-col">
          <p className="text-xs text-[#9B9A96] uppercase tracking-wide mb-2">Tarefas</p>
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[28px] font-semibold font-mono text-[#7C3AED] leading-none block">
                8 / 12
              </span>
              <p className="text-xs text-[#9B9A96] mt-1">concluídas esta semana</p>
            </div>
            <RingChart value={8} max={12} color="#7C3AED" />
          </div>
        </StatCard>

        {/* Dispensa */}
        <StatCard>
          <p className="text-xs text-[#9B9A96] uppercase tracking-wide mb-2">Dispensa</p>
          <span className="text-[28px] font-semibold font-mono text-[#D97706] leading-none block mb-2">
            3 itens
          </span>
          <p className="text-xs text-[#9B9A96]">abaixo do mínimo</p>
        </StatCard>
      </div>

      {/* ── Main Grid (60/40) ── */}
      <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)] gap-4">
        {/* LEFT COLUMN */}
        <div className="flex flex-col gap-4">
          {/* Ciclos de Pagamento */}
          <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-hidden">
            <div className="px-5 py-4 border-b border-[#E4E3E0]">
              <h2 className="text-sm font-medium text-[#1A1917]">Ciclos de Pagamento</h2>
            </div>
            <div>
              {ciclos.map((c) => (
                <div
                  key={c.label}
                  className="flex items-center gap-4 px-5 border-b border-[#E4E3E0] last:border-0"
                  style={{ height: 48 }}
                >
                  <span className="text-sm font-mono text-[#6B6A67] w-12 flex-shrink-0">
                    {c.label}
                  </span>
                  <div className="flex-1">
                    <ProgressBar value={c.paid} max={c.total} height={6} />
                  </div>
                  <span className="text-sm font-mono text-[#059669] w-24 text-right flex-shrink-0">
                    R$ {fmt(c.paid)}
                  </span>
                  <span className="text-sm font-mono text-[#9B9A96] w-24 text-right flex-shrink-0 hidden sm:block">
                    R$ {fmt(c.pending)}
                  </span>
                </div>
              ))}
              {/* Sem data row */}
              <div
                className="flex items-center gap-4 px-5"
                style={{ height: 48 }}
              >
                <span className="text-xs font-mono text-[#9B9A96] bg-[#F0EFED] px-2 py-0.5 rounded-full w-12 text-center flex-shrink-0">
                  Sem dt.
                </span>
                <div className="flex-1">
                  <ProgressBar value={0} max={1} height={6} color="#9B9A96" />
                </div>
                <span className="text-sm font-mono text-[#9B9A96] w-24 text-right flex-shrink-0">
                  R$ 0,00
                </span>
                <span className="text-sm font-mono text-[#9B9A96] w-24 text-right flex-shrink-0 hidden sm:block">
                  R$ 0,00
                </span>
              </div>
            </div>
          </div>

          {/* Últimos Lançamentos */}
          <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-hidden">
            <div className="px-5 py-4 border-b border-[#E4E3E0]">
              <h2 className="text-sm font-medium text-[#1A1917]">Últimos Lançamentos</h2>
            </div>
            <div>
              {lancamentos.map((l) => (
                <div
                  key={l.id}
                  className="flex items-center gap-3 px-5 py-3 border-b border-[#E4E3E0] last:border-0 hover:bg-[#F8F8F7] transition-colors cursor-pointer"
                >
                  <div
                    className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{ background: l.color }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-[#1A1917] truncate">{l.desc}</p>
                    <span className="inline-block text-xs text-[#6B6A67] bg-[#F0EFED] rounded-full px-2 py-0.5 mt-0.5">
                      {l.cat}
                    </span>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p
                      className="text-sm font-mono"
                      style={{ color: l.amount > 0 ? "#059669" : "#3D3C3A" }}
                    >
                      {l.amount > 0 ? "+" : ""}R$ {fmt(Math.abs(l.amount))}
                    </p>
                    <p className="text-xs text-[#9B9A96] font-mono">{l.date}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="px-5 py-3 flex justify-end">
              <button className="text-sm text-[#9B9A96] hover:text-[#1A1917] transition-colors">
                Ver todos →
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN */}
        <div className="flex flex-col gap-4">
          {/* Tarefas de hoje */}
          <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-hidden">
            <div className="px-5 py-4 border-b border-[#E4E3E0] flex items-center justify-between">
              <h2 className="text-sm font-medium text-[#1A1917]">Tarefas de hoje</h2>
              <span className="text-sm text-[#9B9A96]">Sáb, 14</span>
            </div>
            <div className="py-1">
              {tarefasHoje.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center gap-3 px-4 py-2.5 hover:bg-[#F8F8F7] transition-colors cursor-pointer"
                  style={{ borderLeft: "2px solid #7C3AED" }}
                >
                  <div
                    className={`w-4 h-4 rounded-full border flex-shrink-0 flex items-center justify-center transition-colors ${
                      t.done ? "bg-[#7C3AED] border-[#7C3AED]" : "border-[#E4E3E0]"
                    }`}
                  >
                    {t.done && (
                      <svg width="8" height="6" viewBox="0 0 8 6" fill="none">
                        <path d="M1 3L3 5L7 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    )}
                  </div>
                  <span
                    className={`flex-1 text-sm ${
                      t.done ? "line-through text-[#9B9A96] opacity-50" : "text-[#1A1917]"
                    }`}
                  >
                    {t.title}
                  </span>
                  <Avatar initials={t.assignee} size={20} bg={t.done ? "#C8C7C3" : "#1A1917"} />
                </div>
              ))}
            </div>
          </div>

          {/* Próximos Compromissos */}
          <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-hidden">
            <div className="px-5 py-4 border-b border-[#E4E3E0]">
              <h2 className="text-sm font-medium text-[#1A1917]">Próximos Compromissos</h2>
            </div>
            <div>
              {compromissos.map((c, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-3 px-5 py-3 hover:bg-[#F8F8F7] transition-colors cursor-pointer ${
                    i < compromissos.length - 1 ? "border-b border-[#E4E3E0]" : ""
                  }`}
                >
                  <span className="text-xs font-mono text-[#D97706] w-10 flex-shrink-0">
                    {c.time}
                  </span>
                  <span className="text-sm text-[#1A1917]">{c.title}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
