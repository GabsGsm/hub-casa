import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { useState } from "react";

const eventsByDay: Record<number, { time: string; title: string; type: "task" | "event" | "reminder" }[]> = {
  9: [{ time: "09:00", title: "Limpeza geral da casa", type: "task" }],
  10: [{ time: "14:30", title: "Reunião com síndico", type: "event" }],
  11: [{ time: "10:00", title: "Manutenção do ar condicionado", type: "event" }],
  12: [],
  13: [{ time: "11:00", title: "Vistoria da imobiliária", type: "event" }, { time: "19:00", title: "Jantar", type: "event" }],
  14: [{ time: "09:30", title: "Entrega do sofá", type: "reminder" }, { time: "16:00", title: "Manutenção da geladeira", type: "task" }],
  15: [{ time: "10:00", title: "Café da manhã em família", type: "event" }],
  16: [],
  17: [{ time: "09:00", title: "Verificar filtro", type: "reminder" }],
  18: [],
  19: [{ time: "15:00", title: "Entrega de encomenda", type: "reminder" }],
  20: [],
  21: [{ time: "11:00", title: "Visita dos pais", type: "event" }],
  22: [],
  23: [],
  24: [],
  25: [{ time: "18:00", title: "Pagar contas", type: "task" }],
  26: [],
  27: [],
  28: [],
  29: [],
  30: [],
  31: [{ time: "20:00", title: "Confraternização", type: "event" }],
};

const typeColors: Record<string, string> = {
  task: "#7C3AED",
  event: "#D97706",
  reminder: "#2563EB",
};

const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const months = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

export function Agenda() {
  const [currentMonth, setCurrentMonth] = useState(2); // March (0-indexed)
  const [currentYear, setCurrentYear] = useState(2026);
  const [selectedDay, setSelectedDay] = useState(14);

  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  const selectedEvents = eventsByDay[selectedDay] || [];

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-[28px] font-semibold text-[#1A1917]">Agenda</h1>
        <button className="flex items-center gap-1.5 h-9 px-4 bg-[#1A1917] text-white rounded-[8px] text-sm hover:bg-[#3D3C3A] transition-colors">
          <Plus size={14} />
          Novo compromisso
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-5">
        {/* Calendar */}
        <div className="bg-white border border-[#E4E3E0] rounded-[12px] p-5">
          {/* Month navigation */}
          <div className="flex items-center justify-between mb-5">
            <button
              onClick={() => {
                if (currentMonth === 0) { setCurrentMonth(11); setCurrentYear(y => y - 1); }
                else setCurrentMonth(m => m - 1);
              }}
              className="w-7 h-7 flex items-center justify-center rounded-[6px] hover:bg-[#F0EFED] transition-colors"
            >
              <ChevronLeft size={14} className="text-[#6B6A67]" />
            </button>
            <span className="text-sm font-medium text-[#1A1917]">
              {months[currentMonth]} {currentYear}
            </span>
            <button
              onClick={() => {
                if (currentMonth === 11) { setCurrentMonth(0); setCurrentYear(y => y + 1); }
                else setCurrentMonth(m => m + 1);
              }}
              className="w-7 h-7 flex items-center justify-center rounded-[6px] hover:bg-[#F0EFED] transition-colors"
            >
              <ChevronRight size={14} className="text-[#6B6A67]" />
            </button>
          </div>

          {/* Day headers */}
          <div className="grid grid-cols-7 mb-2">
            {weekDays.map((d) => (
              <div key={d} className="text-center text-xs text-[#9B9A96] py-1">{d}</div>
            ))}
          </div>

          {/* Days grid */}
          <div className="grid grid-cols-7 gap-y-1">
            {Array.from({ length: firstDayOfMonth }).map((_, i) => (
              <div key={`empty-${i}`} />
            ))}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const isToday = day === 14 && currentMonth === 2 && currentYear === 2026;
              const isSelected = day === selectedDay && currentMonth === 2 && currentYear === 2026;
              const hasEvents = (eventsByDay[day] || []).length > 0;

              return (
                <button
                  key={day}
                  onClick={() => setSelectedDay(day)}
                  className={`relative h-8 w-full flex items-center justify-center rounded-[6px] text-sm transition-colors ${
                    isSelected
                      ? "bg-[#1A1917] text-white"
                      : isToday
                      ? "bg-[#F0EFED] text-[#1A1917] font-medium"
                      : "text-[#3D3C3A] hover:bg-[#F8F8F7]"
                  }`}
                >
                  {day}
                  {hasEvents && !isSelected && (
                    <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#D97706]" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Events for selected day */}
        <div>
          <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-hidden">
            <div className="px-5 py-4 border-b border-[#E4E3E0]">
              <h2 className="text-sm font-medium text-[#1A1917]">
                {selectedDay} de {months[currentMonth]}
              </h2>
            </div>

            {selectedEvents.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <p className="text-sm text-[#9B9A96]">Nenhum compromisso</p>
                <p className="text-xs text-[#C8C7C3] mt-1">Clique em "Novo compromisso" para adicionar</p>
              </div>
            ) : (
              <div>
                {selectedEvents.map((ev, i) => (
                  <div
                    key={i}
                    className={`flex items-center gap-4 px-5 py-4 hover:bg-[#F8F8F7] transition-colors cursor-pointer ${
                      i < selectedEvents.length - 1 ? "border-b border-[#E4E3E0]" : ""
                    }`}
                  >
                    <div
                      className="w-1 h-8 rounded-full flex-shrink-0"
                      style={{ background: typeColors[ev.type] }}
                    />
                    <div className="flex-1">
                      <p className="text-sm text-[#1A1917]">{ev.title}</p>
                      <span
                        className="text-xs rounded-full px-2 py-0.5 capitalize"
                        style={{
                          background: typeColors[ev.type] + "20",
                          color: typeColors[ev.type],
                        }}
                      >
                        {ev.type === "task" ? "tarefa" : ev.type === "event" ? "evento" : "lembrete"}
                      </span>
                    </div>
                    <span className="text-xs font-mono text-[#D97706] flex-shrink-0">{ev.time}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Upcoming */}
          <div className="bg-white border border-[#E4E3E0] rounded-[12px] overflow-hidden mt-4">
            <div className="px-5 py-4 border-b border-[#E4E3E0]">
              <h2 className="text-sm font-medium text-[#1A1917]">Próximos compromissos</h2>
            </div>
            {[
              { day: 14, time: "09:30", title: "Entrega do sofá", type: "reminder" },
              { day: 14, time: "16:00", title: "Manutenção da geladeira", type: "task" },
              { day: 15, time: "10:00", title: "Café da manhã em família", type: "event" },
              { day: 21, time: "11:00", title: "Visita dos pais", type: "event" },
            ].map((ev, i) => (
              <div
                key={i}
                className="flex items-center gap-3 px-5 py-3 border-b border-[#E4E3E0] last:border-0 hover:bg-[#F8F8F7] transition-colors cursor-pointer"
              >
                <span className="text-xs font-mono text-[#9B9A96] w-8 flex-shrink-0">{ev.day}/03</span>
                <span className="text-xs font-mono text-[#D97706] w-10 flex-shrink-0">{ev.time}</span>
                <div
                  className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                  style={{ background: typeColors[ev.type] }}
                />
                <span className="text-sm text-[#1A1917]">{ev.title}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
