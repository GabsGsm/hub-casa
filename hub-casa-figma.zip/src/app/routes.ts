import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Dashboard } from "./components/dashboard/Dashboard";
import { Financeiro } from "./components/financeiro/Financeiro";
import { Tarefas } from "./components/tarefas/Tarefas";
import { Agenda } from "./components/agenda/Agenda";
import { Compras } from "./components/compras/Compras";
import { Dispensa } from "./components/dispensa/Dispensa";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "financeiro", Component: Financeiro },
      { path: "tarefas", Component: Tarefas },
      { path: "agenda", Component: Agenda },
      { path: "compras", Component: Compras },
      { path: "dispensa", Component: Dispensa },
    ],
  },
]);
